using System;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using System.Linq;
internal static class Probe {
    [System.Runtime.InteropServices.DllImport("shell32",EntryPoint="Shell_NotifyIconW")]static extern bool SetVersion(int cmd,byte[] data);
    static void Version(Entry e,int v){
        byte[] d=new byte[976];BitConverter.GetBytes(976).CopyTo(d,0);BitConverter.GetBytes(e.Owner.ToInt64()).CopyTo(d,8);
        BitConverter.GetBytes(e.Id).CopyTo(d,16);BitConverter.GetBytes(v).CopyTo(d,816);
        Console.WriteLine("setversion="+SetVersion(4,d));Pump();
    }
    static void Pump(){for(int i=0;i<25;i++){Application.DoEvents();Thread.Sleep(10);}}
    [STAThread] static int Main(string[] args){
        using(var a=new NotifyIcon())using(var b=new NotifyIcon()){
            int left=0,right=0,dbl=0;
            a.Icon=b.Icon=SystemIcons.Information;a.Text="收纳验证 A";b.Text="收纳验证 B";
            a.MouseClick+=(s,e)=>{if(e.Button==MouseButtons.Left)left++;if(e.Button==MouseButtons.Right)right++;};
            a.MouseDoubleClick+=(s,e)=>dbl++;
            b.MouseClick+=(s,e)=>{if(e.Button==MouseButtons.Left)left++;if(e.Button==MouseButtons.Right)right++;};b.MouseDoubleClick+=(s,e)=>dbl++;a.Visible=true;Pump();
            if(args.Contains("--fixture")){for(int n=0;n<120;n++)Pump();return 0;}
            b.Visible=true;Pump();Pump();
            var items=Tray.List();var self=items.Where(x=>String.Equals(x.Path,Application.ExecutablePath,StringComparison.OrdinalIgnoreCase)).ToList();
            Console.WriteLine("entries={0} sample={1} distinct={2}",items.Count,self.Count,self.Select(x=>x.Key).Distinct().Count());
            foreach(var e in items)Console.WriteLine("{0} {1} {2} {3}",e.Name,e.Id,e.Overflow,e.Version);if(self.Count==0)return 1;
            foreach(var e in self){
                                if(e.Hidden)continue;
                Version(e,4);var changed=Tray.List().Find(x=>x.Key==e.Key);if(changed==null||changed.Version!=4)return 3;
                Version(e,0);
                try{
                    Console.WriteLine("sample id={0} hide={1}",e.Id,Tray.Hide(e,true));
                    Tray.Click(e,MouseButtons.Left,false);Pump();Tray.Click(e,MouseButtons.Right,false);Pump();
                    Tray.Click(e,MouseButtons.Left,true);Pump();
                }finally{Tray.Hide(e,false);}
            }
            Console.WriteLine("left={0} right={1} double={2}",left,right,dbl);
            if(args.Contains("--roundtrip")){
                var apps=items.Where(x=>x.Overflow&&!x.Hidden&&x.Path!=Application.ExecutablePath).GroupBy(x=>x.Path).Take(2);
                foreach(var group in apps){var e=group.First();try{Console.WriteLine("{0} hidden={1}",e.Name,Tray.Hide(e,true));}finally{Console.WriteLine("{0} restored={1}",e.Name,Tray.Hide(e,false));}}
            }
            return left>0&&right>0&&dbl>0?0:2;
        }
    }
}
