using System;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Serialization;

[assembly: System.Reflection.AssemblyTitle("DragonNest")]
[assembly: System.Reflection.AssemblyProduct("DragonNest")]
[assembly: System.Reflection.AssemblyVersion("1.1.5.0")]
[assembly: System.Reflection.AssemblyFileVersion("1.1.5.0")]
[assembly: System.Reflection.AssemblyInformationalVersion("1.1.5")]

public class Layout {
    public List<string> Order=new List<string>();
    public List<string> Managed=new List<string>();
    public List<string> AutoHide=new List<string>();
    public int PreferredColumns=4;
}
internal sealed class Box : Form {
    static readonly string defaultFile=Path.Combine(Application.StartupPath,"layout.xml");
    readonly XmlSerializer serializer=new XmlSerializer(typeof(Layout));
    readonly Layout state;
    readonly NotifyIcon entrance=new NotifyIcon();
    readonly FlowLayoutPanel grid=new FlowLayoutPanel();
    readonly Icon appIcon=LoadAppIcon();
    string lastNotice;
    DateTime lastNoticeAt;
    readonly ToolTip tips=new ToolTip();
    readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer();
    List<Entry> items=new List<Entry>();
    string signature;
    Entry source, menuIcon;
    bool openedOverflowForMenu, menuForwarded;
    DateTime menuDeadline;
    Form dragGhost;
    Bitmap dragImage;
    Rectangle inlinePreview;
    bool overflowOpenAtDragStart, reopenOverflowAfterDrop;
    DateTime keepPanelOpenUntil;
    bool startedDrag, dropOverPanel, dropAfter, dismissOnOutsideClick;
    PictureBox dropTarget;
    Point dragPosition;
    string outgoing,pending;
    Point start, windowDragOffset;
    bool draggingWindow;
    enum ResizeEdge { None, Left, Top }
    ResizeEdge resizeEdge;
    Point resizeStart, resizeAnchor;
    int resizeStartColumns, resizeStartRows, resizeColumns, cellSize;
    bool escaped,swallowUp,overflowWasVisible,panelSawOverflow,acrylic;
    DateTime refresh,clickAt,contextMenuUntil;
    IntPtr hook;
    delegate IntPtr HookProc(int n,IntPtr msg,IntPtr data);
    readonly HookProc proc;
    [DllImport("user32")] static extern IntPtr SetWindowsHookEx(int id,HookProc proc,IntPtr module,uint thread);
    [DllImport("user32")] static extern bool UnhookWindowsHookEx(IntPtr h);
    [DllImport("user32")] static extern IntPtr CallNextHookEx(IntPtr h,int n,IntPtr w,IntPtr l);
    [DllImport("kernel32")] static extern IntPtr GetModuleHandle(string name);
    [DllImport("user32")] static extern IntPtr WindowFromPoint(Point p);
    [DllImport("user32",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr window,System.Text.StringBuilder name,int capacity);
    [DllImport("user32")] static extern bool IsChild(IntPtr parent,IntPtr child);
    [DllImport("user32")] static extern bool GetWindowRect(IntPtr h,out Rect r);
    [StructLayout(LayoutKind.Sequential)] struct Rect {public int L,T,R,B;}
    [DllImport("user32")] static extern int SetWindowCompositionAttribute(IntPtr hwnd,ref CompositionData data);
    [DllImport("dwmapi")] static extern int DwmExtendFrameIntoClientArea(IntPtr hwnd,ref FrameMargins margins);
    [StructLayout(LayoutKind.Sequential)] struct FrameMargins {public int Left,Right,Top,Bottom;}
    [StructLayout(LayoutKind.Sequential)] struct AccentPolicy {
        public int State, Flags;
        public uint Color;
        public int AnimationId;
    }
    [StructLayout(LayoutKind.Sequential)] struct CompositionData {
        public int Attribute;
        public IntPtr Data;
        public UIntPtr Size;
    }

    static Icon LoadAppIcon(){
        using(var stream=typeof(Box).Assembly.GetManifestResourceStream("TrayNest10.ico"))
            return new Icon(stream,SystemInformation.SmallIconSize);
    }

    ResizeEdge EdgeAt(Point point){
        if(grid.Controls.Count==0)return ResizeEdge.None;
        int grip=Math.Max(1,cellSize/10);
        if(point.X<grip)return ResizeEdge.Left;
        if(point.Y<grip)return ResizeEdge.Top;
        return ResizeEdge.None;
    }

    Cursor EdgeCursor(Point point){
        var edge=EdgeAt(point);
        return edge==ResizeEdge.Left?Cursors.SizeWE:edge==ResizeEdge.Top?Cursors.SizeNS:Cursors.Default;
    }

    bool StartResize(Point point){
        resizeEdge=EdgeAt(point);
        if(resizeEdge==ResizeEdge.None)return false;

        if(Tray.IsWindowVisible(Tray.OverflowWindow))PositionBox();
        resizeStart=Cursor.Position;
        resizeAnchor=new Point(Right,Bottom);
        resizeStartColumns=resizeColumns=ClientSize.Width/cellSize;
        resizeStartRows=ClientSize.Height/cellSize;
        pending=null;
        grid.Capture=true;
        return true;
    }

    void GridMouseDown(object sender,MouseEventArgs e){
        if(e.Button!=MouseButtons.Left||grid.GetChildAtPoint(e.Location)!=null)return;
        if(StartResize(e.Location))return;
        windowDragOffset=new Point(Cursor.Position.X-Left,Cursor.Position.Y-Top);
        draggingWindow=true;
        grid.Capture=true;
    }

    void GridMouseMove(object sender,MouseEventArgs e){
        var cursor=Cursor.Position;
        if(resizeEdge!=ResizeEdge.None){
            int count=grid.Controls.Count;
            if(count==0)return;
            var work=Screen.FromControl(this).WorkingArea;
            int maxColumns=Math.Max(1,(resizeAnchor.X-work.Left)/cellSize);
            int maxRows=Math.Max(1,(resizeAnchor.Y-work.Top)/cellSize);
            int minColumns=Math.Min(maxColumns,(count+maxRows-1)/maxRows);
            int delta=resizeEdge==ResizeEdge.Left?resizeStart.X-cursor.X:resizeStart.Y-cursor.Y;
            int cells=(int)Math.Round((double)delta/cellSize,MidpointRounding.AwayFromZero);
            int columns;
            if(resizeEdge==ResizeEdge.Left){
                columns=resizeStartColumns+cells;
            }else{
                int rows=Math.Max(1,Math.Min(count,resizeStartRows+cells));
                columns=rows==resizeStartRows?resizeStartColumns:(count+rows-1)/rows;
            }
            resizeColumns=Math.Max(minColumns,Math.Min(Math.Min(count,maxColumns),columns));
            ApplyGridSize(resizeColumns,resizeAnchor);
        }else if(draggingWindow){
            Location=new Point(cursor.X-windowDragOffset.X,cursor.Y-windowDragOffset.Y);
        }else{
            grid.Cursor=EdgeCursor(e.Location);
        }
    }

    void GridMouseUp(object sender,MouseEventArgs e){
        if(e.Button==MouseButtons.Left&&(draggingWindow||resizeEdge!=ResizeEdge.None))grid.Capture=false;
    }

    void GridCaptureChanged(object sender,EventArgs e){
        if(grid.Capture)return;
        draggingWindow=false;
        if(resizeEdge==ResizeEdge.None)return;
        resizeEdge=ResizeEdge.None;
        grid.Cursor=Cursors.Default;
        if(resizeColumns!=resizeStartColumns){
            state.PreferredColumns=resizeColumns;
            Safe(Save);
        }
    }

    protected override bool ShowWithoutActivation {get{return true;}}

    protected override void WndProc(ref Message m){
        if(m.Msg==0x21){m.Result=new IntPtr(3);return;} // MA_NOACTIVATE
        base.WndProc(ref m);
        if(m.Msg==0x1a||m.Msg==0x31a||m.Msg==0x31e)ApplyBackdrop();
    }

    protected override void OnHandleCreated(EventArgs e){
        base.OnHandleCreated(e);
        ApplyBackdrop();
    }

    void ApplyBackdrop(){
        if(!IsHandleCreated||IsDisposed)return;
        bool highContrast=SystemInformation.HighContrast;
        bool transparent=!highContrast&&!object.Equals(Microsoft.Win32.Registry.GetValue(
            @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize","EnableTransparency",1),0);
        acrylic=transparent&&SetBackdrop(4,0,0x66303030);
        if(transparent&&!acrylic)acrylic=SetBackdrop(3,2,0x66303030);
        if(!acrylic)SetBackdrop(0,0,0);
        var margins=new FrameMargins{Left=acrylic?-1:0};
        DwmExtendFrameIntoClientArea(Handle,ref margins);
        BackColor=acrylic?Color.Black:highContrast?SystemColors.Window:Color.FromArgb(55,55,55);
        ForeColor=highContrast?SystemColors.WindowText:Color.White;
        Invalidate(true);
    }

    bool SetBackdrop(int state,int flags,uint tint){
        var policy=new AccentPolicy{State=state,Flags=flags,Color=tint};
        int size=Marshal.SizeOf(typeof(AccentPolicy));
        var data=new CompositionData{Attribute=19,Data=Marshal.AllocHGlobal(size),Size=(UIntPtr)size};
        try{
            Marshal.StructureToPtr(policy,data.Data,false);
            return SetWindowCompositionAttribute(Handle,ref data)!=0;
        }catch(EntryPointNotFoundException){return false;}
        finally{Marshal.FreeHGlobal(data.Data);}
    }
    readonly string stateFile; internal Box(string file=null){ stateFile=file??defaultFile;
        if(file==null&&string.Equals(Path.GetPathRoot(stateFile),@"C:\",StringComparison.OrdinalIgnoreCase))
            throw new IOException("请将 DragonNest 移到非 C 盘的可写目录。收纳规则保存在 EXE 同目录。");
        Directory.CreateDirectory(Path.GetDirectoryName(stateFile));
        if(File.Exists(stateFile)){using(var f=File.OpenRead(stateFile))state=(Layout)serializer.Deserialize(f);}else state=new Layout();
        if(file==null)Save(); // Verify storage before changing any tray icons.
        Text="DragonNest";TopMost=true;ShowInTaskbar=false;FormBorderStyle=FormBorderStyle.None;
        AutoScaleMode=AutoScaleMode.Dpi;ClientSize=new Size(40,40);StartPosition=FormStartPosition.Manual;
        grid.Dock=DockStyle.Fill;grid.AutoScroll=false;grid.FlowDirection=FlowDirection.LeftToRight;grid.WrapContents=true;grid.BackColor=Color.Transparent;Controls.Add(grid);
        grid.Paint+=(s,e)=>{if(dropOverPanel&&dropTarget==null)PaintDrop(e.Graphics,grid.ClientRectangle,false);PaintInlinePreview(grid,e.Graphics);};
        grid.MouseDown+=GridMouseDown;
        grid.MouseMove+=GridMouseMove;
        grid.MouseUp+=GridMouseUp;
        grid.MouseCaptureChanged+=GridCaptureChanged;
        Icon=appIcon;entrance.Icon=appIcon;entrance.Text=Text;
        var menu=new ContextMenuStrip();
        menu.Items.Add("全部还原",null,(s,e)=>Safe(()=>Restore(true)));var startup=new ToolStripMenuItem("开机自启");
        startup.Checked=CheckAutoStart();
        startup.Click+=(s,e)=>Safe(()=>{SetAutoStart(!startup.Checked);startup.Checked=CheckAutoStart();});
        menu.Items.Add(startup);
        menu.Items.Add("退出",null,(s,e)=>ExitBox());
        entrance.ContextMenuStrip=menu;entrance.MouseClick+=(s,e)=>{if(e.Button==MouseButtons.Left){if(Visible)Hide();else OpenBox();}};
        entrance.Visible=true;proc=OnMouse;
        var ready=Handle;
        Safe(()=>{Restore(false);Sync();});
        timer.Interval=30;timer.Tick+=(s,e)=>Safe(Tick);timer.Start();
        VisibleChanged+=(s,e)=>{if(Visible){hook=SetWindowsHookEx(14,proc,GetModuleHandle(null),0);if(hook==IntPtr.Zero)Notice("无法监听拖动，请关闭后重新打开面板。");}else StopHook();};
        FormClosing+=(s,e)=>{if(e.CloseReason==CloseReason.UserClosing&&!quit){e.Cancel=true;Hide();return;}try{Restore(false);}catch(Exception ex){if(e.CloseReason==CloseReason.UserClosing){e.Cancel=true;quit=false;Notice(ex.Message);}}};

    }
    protected override void Dispose(bool disposing){
        if(disposing&&!IsDisposed){
            StopHook();timer.Dispose();entrance.Dispose();appIcon.Dispose();tips.Dispose();
            foreach(PictureBox cell in grid.Controls)if(cell.Image!=null)cell.Image.Dispose();
        }
        base.Dispose(disposing);
    }
    bool quit; internal void ExitBox(){quit=true;Close();}
    void StopHook(){if(hook!=IntPtr.Zero){UnhookWindowsHookEx(hook);hook=IntPtr.Zero;}source=null;swallowUp=false;outgoing=null;reopenOverflowAfterDrop=false;keepPanelOpenUntil=DateTime.MinValue;dismissOnOutsideClick=false;ClearDragPreview();if(draggingWindow||resizeEdge!=ResizeEdge.None)grid.Capture=false;draggingWindow=false;}
    internal void OpenBox(){
        contextMenuUntil=DateTime.MinValue;
        panelSawOverflow=Tray.IsWindowVisible(Tray.OverflowWindow);
        Safe(Sync);
        PositionBox();
        Show();
    }
    void PositionBox(){
        var work=Screen.FromPoint(Cursor.Position).WorkingArea;
        Rect r;int x=work.Right-Width-190,y=work.Bottom-Height-6;
        if(GetWindowRect(Tray.OverflowWindow,out r)&&r.R>r.L){x=r.L-Width-8;y=r.B-Height;if(x<work.Left)x=r.R+8;if(x+Width>work.Right){x=r.L;y=r.T-Height-8;}}
        Location=new Point(Math.Max(work.Left,Math.Min(work.Right-Width,x)),Math.Max(work.Top,Math.Min(work.Bottom-Height,y)));
    }
    void Safe(Action a){try{a();}catch(Exception ex){Notice(ex.Message);}}
    void Notice(string message){
        var now=DateTime.UtcNow;
        if(message==lastNotice&&now-lastNoticeAt<TimeSpan.FromSeconds(10))return;
        lastNotice=message;lastNoticeAt=now;
        entrance.ShowBalloonTip(3000,Text,message,ToolTipIcon.Warning);
    }
    const string StartupKey=@"Software\Microsoft\Windows\CurrentVersion\Run";
    const string StartupName="TrayNest10";
    static bool CheckAutoStart(){
        try{
            using(var key=Microsoft.Win32.Registry.CurrentUser.OpenSubKey(StartupKey))
                return key!=null&&key.GetValue(StartupName)!=null;
        }catch(UnauthorizedAccessException){return false;}
        catch(System.Security.SecurityException){return false;}
    }
    static void SetAutoStart(bool enable){
        using(var key=Microsoft.Win32.Registry.CurrentUser.CreateSubKey(StartupKey)){
            if(key==null)throw new IOException("无法访问当前用户的启动设置。");
            if(enable)key.SetValue(StartupName,"\""+Application.ExecutablePath+"\"",Microsoft.Win32.RegistryValueKind.String);
            else key.DeleteValue(StartupName,false);
        }
    }
    static string AppPath(string key){return key.Substring(0,key.LastIndexOf('|'));}
    void Save(){
        string tmp=stateFile+".tmp";
        using(var f=File.Create(tmp)){serializer.Serialize(f,state);f.Flush(true);}
        if(File.Exists(stateFile))File.Replace(tmp,stateFile,null);else File.Move(tmp,stateFile);
    }
    Entry Unique(string key){var matches=items.Where(x=>x.Key==key).Take(2).ToArray();return matches.Length==1?matches[0]:null;}
    void Restore(bool clear){
        FinishMenu();
        items=Tray.List();
        foreach(var key in state.Managed.ToArray()){
            var entry=Unique(key);
            if(entry==null){if(items.Any(x=>x.Key==key))throw new IOException("图标身份重复，暂时无法还原。");continue;}
            if(entry.Hidden&&!Tray.Hide(entry,false))throw new IOException("还原失败，请重试。");
            state.Managed.Remove(key);
        }
        if(clear){state.Order.Clear();state.AutoHide.Clear();}Save();signature=null;
    }
    void Sync(){
        items=Tray.List();
        foreach(var key in state.Managed.Except(state.Order).ToArray()){var old=Unique(key);if(old!=null&&(!old.Hidden||Tray.Hide(old,false))){state.Managed.Remove(key);Save();}}
        foreach(var entry in items){
            if(!entry.Overflow||entry.Hidden||state.Order.Contains(entry.Key)||Unique(entry.Key)==null)continue;
            if(!state.AutoHide.Contains(entry.Path,StringComparer.OrdinalIgnoreCase))continue;
            state.Order.Add(entry.Key);
            Save();
        }
        bool visibilityChanged=false;
        foreach(var key in state.Order.ToArray()){
            var e=Unique(key);if(e==null)continue;
            if(menuIcon!=null&&menuIcon.Key==e.Key&&menuIcon.Owner==e.Owner){e.Hidden=true;continue;}
            if(e.Hidden||!e.Overflow)continue;
            if(!state.Managed.Contains(key)){state.Managed.Add(key);Save();}
            if(!Tray.Hide(e,true))throw new IOException("该图标暂时无法收纳。");
            e.Hidden=true;
            visibilityChanged=true;
        }
        if(menuIcon==null&&Tray.IsWindowVisible(Tray.OverflowWindow)&&Tray.ArrangeFourInSquare(visibilityChanged?Tray.List():items)){
            if(Visible&&!draggingWindow&&resizeEdge==ResizeEdge.None&&source==null&&outgoing==null)PositionBox();
        }
        var visibleEntries=state.Order.Select(Unique).Where(e=>e!=null&&e.Hidden).ToArray();
        string next=string.Join("\n",visibleEntries.Select(e=>e.Key+" "+IconIdentity(e)));
        if(next!=signature&&outgoing==null){DrawItems(visibleEntries);signature=next;}
    }
    static string IconIdentity(Entry entry){
        return entry.Owner+":"+entry.IconHandle;
    }
    void DrawItems(Entry[] visibleEntries){
        var previous=grid.Controls.Cast<PictureBox>().ToDictionary(cell=>(string)cell.Tag);
        grid.SuspendLayout();
        try{
            grid.Controls.Clear();
            PopulateGrid(previous,visibleEntries);
        }finally{
            foreach(var cell in previous.Values){
                if(cell.Image!=null)cell.Image.Dispose();
                cell.Dispose();
            }
            grid.ResumeLayout();
        }
    }
    void PopulateGrid(Dictionary<string,PictureBox> previous,Entry[] visibleEntries){
        int dpi;
        using(var graphics=grid.CreateGraphics())dpi=(int)Math.Round(graphics.DpiX);
        cellSize=(40*dpi+48)/96;
        int iconSize=(16*dpi+48)/96;
        foreach(var e in visibleEntries){
            string key=e.Key;
            var c=new PictureBox{Tag=key,Size=new Size(cellSize,cellSize),SizeMode=PictureBoxSizeMode.CenterImage,Cursor=Cursors.Hand,BackColor=Color.Transparent,Margin=Padding.Empty};
            c.Name=IconIdentity(e);
            c.Paint+=(s,a)=>{if(dropTarget==c)PaintDrop(a.Graphics,c.ClientRectangle,dropAfter);PaintInlinePreview(c,a.Graphics);};
            PictureBox old;
            if(previous.TryGetValue(key,out old)&&old.Name==c.Name&&old.Image!=null&&old.Image.Width==iconSize){
                c.Image=old.Image;
                old.Image=null;
            }else{
                c.Image=Tray.ReadIcon(e,iconSize)??SystemIcons.Application.ToBitmap();
            }
            tips.SetToolTip(c,Path.GetFileName(e.Path)+" · "+e.Id);
            var local=key;
            c.MouseMove+=(s,a)=>{
                if(outgoing!=null)return;
                var cursor=EdgeCursor(new Point(c.Left+a.X,c.Top+a.Y));
                c.Cursor=cursor==Cursors.Default?Cursors.Hand:cursor;
            };
            c.MouseDown+=(s,a)=>{
                if(a.Button!=MouseButtons.Left||StartResize(new Point(c.Left+a.X,c.Top+a.Y)))return;
                outgoing=local;
                overflowOpenAtDragStart=Tray.IsWindowVisible(Tray.OverflowWindow);
                reopenOverflowAfterDrop=false;
                start=c.PointToScreen(a.Location);
                escaped=startedDrag=false;
                c.Capture=true;
            };
            c.MouseCaptureChanged+=(s,a)=>{
                if(c.Capture||outgoing!=local)return;
                if(startedDrag)ProtectAfterDrag();
                outgoing=null;
                startedDrag=false;
                ClearDragPreview();
            };
            c.MouseUp+=(s,a)=>Safe(()=>{
                if(a.Button==MouseButtons.Right){
                    if((ModifierKeys&Keys.Shift)!=0)Remove(local);
                    else InvokeIcon(local,MouseButtons.Right,false);
                    return;
                }
                if(a.Button!=MouseButtons.Left||outgoing!=local)return;
                var pos=c.PointToScreen(a.Location);
                bool moved=startedDrag||Moved(pos);
                if(moved)ProtectAfterDrag();
                outgoing=null;
                startedDrag=false;
                c.Capture=false;
                ClearDragPreview();
                if(escaped||Tray.GetAsyncKeyState(27)<0)return;
                if(moved){
                    pending=null;
                    var overflow=Tray.OverflowWindow;
                    Rect bounds;
                    if(Tray.IsWindowVisible(overflow)&&GetWindowRect(overflow,out bounds)
                            &&Rectangle.FromLTRB(bounds.L,bounds.T,bounds.R,bounds.B).Contains(pos)){
                        Remove(local);
                        return;
                    }
                    PictureBox target;
                    bool after;
                    int index=FindDrop(pos,out target,out after);
                    if(index<0)return;
                    int oldIndex=state.Order.IndexOf(local);
                    if(oldIndex<0)return;
                    reopenOverflowAfterDrop=overflowOpenAtDragStart;
                    if(index>oldIndex)index--;
                    if(index==oldIndex)return;
                    state.Order.RemoveAt(oldIndex);
                    state.Order.Insert(index,local);
                    Save();signature=null;Sync();
                }else if(pending==local&&DateTime.UtcNow<clickAt){
                    pending=null;InvokeIcon(local,MouseButtons.Left,true);
                }else{
                    pending=local;clickAt=DateTime.UtcNow.AddMilliseconds(SystemInformation.DoubleClickTime);
                }
            });
            grid.Controls.Add(c);
        }
        ApplyGridSize(state.PreferredColumns,null);
    }

    void ApplyGridSize(int preferredColumns,Point? anchor){
        int count=Math.Max(1,grid.Controls.Count);
        int columns=Math.Max(1,Math.Min(count,preferredColumns));
        int rows=(count+columns-1)/columns;
        var size=new Size(columns*cellSize,rows*cellSize);
        if(ClientSize==size)return;
        if(anchor.HasValue){
            var point=anchor.Value;
            SetBounds(point.X-size.Width,point.Y-size.Height,size.Width,size.Height);
        }else{
            ClientSize=size;
            if(Visible&&!draggingWindow&&Tray.IsWindowVisible(Tray.OverflowWindow))PositionBox();
        }
    }
    bool Moved(Point pt){var d=SystemInformation.DragSize;return Math.Abs(pt.X-start.X)>=d.Width/2||Math.Abs(pt.Y-start.Y)>=d.Height/2;}
    void InvokeIcon(string key,MouseButtons button,bool twice){
        items=Tray.List();
        var entry=Unique(key);
        if(entry==null){Notice("原程序离线或图标身份重复。");return;}

        if(button==MouseButtons.Right){
            dismissOnOutsideClick=true;
            contextMenuUntil=DateTime.UtcNow.AddSeconds(2);
            if(Tray.MenuNeedsVisibleIcon(entry)){
                if(menuIcon!=null)return;
                menuIcon=entry;
                menuForwarded=false;
                openedOverflowForMenu=!Tray.IsWindowVisible(Tray.OverflowWindow);
                menuDeadline=DateTime.UtcNow.AddMilliseconds(750);
                try{
                    if(!Tray.Hide(entry,false))throw new IOException("无法临时显示此图标的原生菜单。");
                    if(openedOverflowForMenu)Tray.OpenOverflow();
                    UpdateMenu();
                }catch{FinishMenu();throw;}
                return;
            }
        }
        Tray.Click(entry,button,twice);
    }
    void UpdateMenu(){
        if(menuIcon==null)return;
        var now=DateTime.UtcNow;
        if(!menuForwarded&&Tray.CanLocateIcon(menuIcon)){
            try{Tray.Click(menuIcon,MouseButtons.Right,false);}
            catch{FinishMenu();throw;}
            menuForwarded=true;
            menuDeadline=now.AddMilliseconds(350);
        }else if(now>=menuDeadline){
            bool failed=!menuForwarded;
            FinishMenu();
            if(failed)Notice("无法定位原托盘图标，菜单未打开。");
        }
    }

    void FinishMenu(){
        if(menuIcon==null)return;
        var entry=menuIcon;
        menuIcon=null;
        try{
            var live=Tray.List().Find(e=>e.Key==entry.Key&&e.Owner==entry.Owner);
            if(live!=null&&!live.Hidden&&!Tray.Hide(live,true))Notice("图标暂时无法重新收纳。");
        }finally{
            if(openedOverflowForMenu)Tray.CloseOverflow();
        }
    }

    void Remove(string key){
        if(menuIcon!=null&&menuIcon.Key==key)FinishMenu();
        items=Tray.List();var e=Unique(key);if(e!=null&&e.Hidden&&!Tray.Hide(e,false))throw new IOException("无法还原图标");
        state.Order.Remove(key);state.Managed.Remove(key);state.AutoHide.RemoveAll(path=>String.Equals(path,AppPath(key),StringComparison.OrdinalIgnoreCase));Save();signature=null;Sync();
    }
    sealed class DragGhost : Form {
        readonly Bitmap image;
        internal DragGhost(Bitmap image){
            this.image=image;
            FormBorderStyle=FormBorderStyle.None;
            ShowInTaskbar=false;
            TopMost=true;
            StartPosition=FormStartPosition.Manual;
            AutoScaleMode=AutoScaleMode.None;
            ClientSize=image.Size;
            BackColor=TransparencyKey=Color.Magenta;
            Opacity=0.7;
        }
        protected override bool ShowWithoutActivation {get{return true;}}
        protected override CreateParams CreateParams{
            get{
                var cp=base.CreateParams;
                cp.ExStyle|=0x08000000|0x20|0x80; // No activation, click-through, tool window.
                return cp;
            }
        }
        protected override void OnPaint(PaintEventArgs e){e.Graphics.DrawImageUnscaled(image,Point.Empty);}
        protected override void Dispose(bool disposing){
            if(disposing&&!IsDisposed)image.Dispose();
            base.Dispose(disposing);
        }
    }

    bool OverPanel(Point pos){
        if(!Visible||!ClientRectangle.Contains(PointToClient(pos)))return false;
        var hit=WindowFromPoint(pos);
        return hit==Handle||IsChild(Handle,hit);
    }

    PictureBox DropCell(Point pos){return grid.GetChildAtPoint(grid.PointToClient(pos)) as PictureBox;}

    int FindDrop(Point pos,out PictureBox target,out bool after){
        target=null;
        after=false;
        if(!OverPanel(pos))return -1;
        target=DropCell(pos);
        if(target==null){
            if(grid.Controls.Count>0){
                target=(PictureBox)grid.Controls[grid.Controls.Count-1];
                after=true;
            }
            return state.Order.Count;
        }
        after=target.PointToClient(pos).X>=target.Width/2;
        if(after){
            int nextIndex=grid.Controls.GetChildIndex(target)+1;
            var next=nextIndex<grid.Controls.Count?grid.Controls[nextIndex] as PictureBox:null;
            // Both halves bordering the same gap use the next tile's leading edge.
            if(next!=null&&next.Top==target.Top&&next.Left==target.Right){
                target=next;
                after=false;
            }
        }
        int index=state.Order.IndexOf((string)target.Tag);
        return index<0?-1:index+(after?1:0);
    }

    void SetDropPreview(bool over,PictureBox target,bool after){
        if(dropOverPanel==over&&dropTarget==target&&dropAfter==after)return;
        if(dropTarget!=null)dropTarget.Invalidate();
        dropOverPanel=over;
        dropTarget=target;
        dropAfter=after;
        grid.Invalidate();
        if(target!=null)target.Invalidate();
    }

    static void PaintDrop(Graphics graphics,Rectangle bounds,bool after){
        int x=after?bounds.Right-2:bounds.Left+1;
        using(var line=new Pen(Color.FromArgb(202,160,255),2))
            graphics.DrawLine(line,x,bounds.Top+4,x,bounds.Bottom-4);
    }

    void SetInlinePreview(Rectangle bounds){
        if(bounds==inlinePreview)return;
        if(!inlinePreview.IsEmpty)grid.Invalidate(inlinePreview,true);
        inlinePreview=bounds;
        if(!bounds.IsEmpty)grid.Invalidate(bounds,true);
    }

    void PaintInlinePreview(Control surface,Graphics graphics){
        if(dragImage==null||inlinePreview.IsEmpty)return;
        var bounds=inlinePreview;
        if(surface!=grid)bounds.Offset(-surface.Left,-surface.Top);
        if(!bounds.IntersectsWith(surface.ClientRectangle))return;
        using(var attributes=new System.Drawing.Imaging.ImageAttributes()){
            var opacity=new System.Drawing.Imaging.ColorMatrix();
            opacity.Matrix33=0.7f;
            attributes.SetColorMatrix(opacity);
            graphics.DrawImage(dragImage,bounds,0,0,dragImage.Width,dragImage.Height,GraphicsUnit.Pixel,attributes);
        }
    }

    void ClearDragPreview(){
        if(dragGhost!=null){dragGhost.Dispose();dragGhost=null;}
        SetInlinePreview(Rectangle.Empty);
        if(dragImage!=null){dragImage.Dispose();dragImage=null;}
        SetDropPreview(false,null,false);
    }

    void UpdateDragPreview(){
        if((source==null&&outgoing==null)||escaped||!startedDrag){ClearDragPreview();return;}
        Point pos=dragPosition;
        if(dragImage==null){
            if(source!=null){
                dragImage=Tray.ReadIcon(source,SystemInformation.SmallIconSize.Width);
            }else{
                var cell=grid.Controls.OfType<PictureBox>().FirstOrDefault(c=>(string)c.Tag==outgoing);
                if(cell!=null&&cell.Image!=null)dragImage=new Bitmap(cell.Image);
            }
            if(dragImage==null)dragImage=appIcon.ToBitmap();
        }

        PictureBox target;
        bool after;
        bool over=FindDrop(pos,out target,out after)>=0;
        if(source==null&&over){
            if(dragGhost!=null){dragGhost.Dispose();dragGhost=null;}
            var local=grid.PointToClient(pos);
            int x=Math.Max(0,Math.Min(grid.Width-dragImage.Width,local.X+12));
            int y=Math.Max(0,Math.Min(grid.Height-dragImage.Height,local.Y+12));
            SetInlinePreview(new Rectangle(new Point(x,y),dragImage.Size));
        }else{
            SetInlinePreview(Rectangle.Empty);
            if(dragGhost==null)dragGhost=new DragGhost(new Bitmap(dragImage));
            dragGhost.Location=new Point(pos.X+12,pos.Y+12);
            if(!dragGhost.Visible)dragGhost.Show();
        }
        SetDropPreview(over,target,after);
    }

    void ProtectAfterDrag(){
        if(!overflowOpenAtDragStart)return;
        keepPanelOpenUntil=DateTime.UtcNow.AddMilliseconds(400);
        if(!Tray.IsWindowVisible(Tray.OverflowWindow))panelSawOverflow=false;
    }

    bool ShouldDismissAfterMenu(Point pos){
        if(!dismissOnOutsideClick||!Visible||source!=null||outgoing!=null||draggingWindow||resizeEdge!=ResizeEdge.None)return false;
        var hit=WindowFromPoint(pos);
        if(hit==Handle||IsChild(Handle,hit))return false;

        var overflow=Tray.OverflowWindow;
        if(Tray.IsWindowVisible(overflow)&&(hit==overflow||IsChild(overflow,hit)))return false;
        // The entrance owns its click toggle, including when it is pinned to the taskbar.
        if(items.Exists(e=>!e.Hidden&&e.Bar==hit&&e.Rect.Contains(pos)
                &&String.Equals(e.Path,Application.ExecutablePath,StringComparison.OrdinalIgnoreCase)))return false;

        var name=new System.Text.StringBuilder(32);
        GetClassName(hit,name,name.Capacity);
        return name.ToString()!="#32768"; // Native context menu.
    }

    IntPtr OnMouse(int n,IntPtr msg,IntPtr data){
        if(n>=0){
            int m=msg.ToInt32();Point pt=(Point)Marshal.PtrToStructure(data,typeof(Point));
            bool pressed=m==0x201||m==0x204||m==0x207||m==0x20b;
            if(pressed&&outgoing==null&&!OverPanel(pt)){
                keepPanelOpenUntil=DateTime.MinValue;
                reopenOverflowAfterDrop=false;
            }
            if(pressed&&ShouldDismissAfterMenu(pt)){
                BeginInvoke((Action)(()=>{if(Visible&&dismissOnOutsideClick)Hide();}));
            }
            if(m==0x201){
                IntPtr hit=WindowFromPoint(pt);
                var e=items.Find(x=>x.Overflow&&!x.Hidden&&x.Bar==hit&&x.Rect.Contains(pt)&&!String.Equals(x.Path,Application.ExecutablePath,StringComparison.OrdinalIgnoreCase));
                if(e!=null){
                    source=e;start=dragPosition=pt;escaped=startedDrag=false;swallowUp=true;
                    return new IntPtr(1);
                }
            }else if(m==0x204&&panelSawOverflow&&(ModifierKeys&Keys.Shift)==0&&OverPanel(pt)&&DropCell(pt)!=null){
                // Explorer can begin dismissing the overflow before MouseUp forwards the menu.
                contextMenuUntil=DateTime.UtcNow.AddSeconds(1);
            }else if(m==0x200&&(source!=null||outgoing!=null)){
                dragPosition=pt;
                if(!startedDrag&&Moved(pt)){startedDrag=true;pending=null;}
            }else if(m==0x202&&swallowUp){
                var e=source;
                bool cancel=escaped||Tray.GetAsyncKeyState(27)<0;
                bool didMove=startedDrag||Moved(pt);
                int index=-1;
                if(!cancel&&didMove){
                    PictureBox target;
                    bool after;
                    index=FindDrop(pt,out target,out after);
                }
                source=null;swallowUp=false;startedDrag=false;
                BeginInvoke((Action)(()=>Safe(()=>{
                    ClearDragPreview();
                    if(cancel||e==null||didMove&&index<0)return;
                    items=Tray.List();var live=Unique(e.Key);
                    if(live==null||live.Owner!=e.Owner){Notice("无法唯一识别此图标。");return;}
                    if(!didMove){Tray.Click(live,MouseButtons.Left,false);return;}
                    if(state.Order.Contains(live.Key))return;
                    state.Order.Insert(Math.Min(index,state.Order.Count),live.Key);Save();Sync();
                    var collected=Unique(live.Key);
                    if(collected!=null&&collected.Hidden&&!state.AutoHide.Contains(live.Path,StringComparer.OrdinalIgnoreCase)){
                        state.AutoHide.Add(live.Path);
                        Save();
                    }
                })));
                return new IntPtr(1);
            }
        }return CallNextHookEx(hook,n,msg,data);
    }
    void Tick(){
        UpdateMenu();
        if((source!=null||outgoing!=null)&&Tray.GetAsyncKeyState(27)<0)escaped=true;
        UpdateDragPreview();
        if(pending!=null&&DateTime.UtcNow>=clickAt){var key=pending;pending=null;InvokeIcon(key,MouseButtons.Left,false);}
        var overflow=Tray.OverflowWindow;
        bool open=Tray.IsWindowVisible(overflow);
        var now=DateTime.UtcNow;
        bool overflowReopened=false;
        if(reopenOverflowAfterDrop){
            if(now>keepPanelOpenUntil&&panelSawOverflow){
                reopenOverflowAfterDrop=false;
            }else if(!open){
                reopenOverflowAfterDrop=false;
                panelSawOverflow=false;
                Tray.OpenOverflow();
                open=Tray.IsWindowVisible(overflow);
                overflowReopened=open;
            }
        }
        if(open){
            if(Visible){
                panelSawOverflow=true;
            }
        }else if(Visible&&panelSawOverflow&&(now<=contextMenuUntil||now<=keepPanelOpenUntil
                ||outgoing!=null&&startedDrag&&overflowOpenAtDragStart)){
            // Ignore an overflow dismissal caused by a menu or drag. Rearm on the next open.
            panelSawOverflow=false;
        }else if(Visible&&panelSawOverflow&&source==null&&outgoing==null&&!draggingWindow&&resizeEdge==ResizeEdge.None){
            Hide();
        }
        if(open&&(!overflowWasVisible||overflowReopened)){
            refresh=DateTime.MinValue;
            if(Visible&&menuIcon==null&&source==null&&outgoing==null&&!draggingWindow&&resizeEdge==ResizeEdge.None)PositionBox();
        }
        overflowWasVisible=open;
        if((Visible||open||state.Order.Count>0||state.Managed.Count>0||state.AutoHide.Count>0)&&DateTime.UtcNow>=refresh&&source==null&&outgoing==null&&resizeEdge==ResizeEdge.None){refresh=DateTime.UtcNow.AddMilliseconds(Visible||open?350:2000);Sync();}
    }
    [STAThread] static void Main(){
        bool first;using(var mutex=new Mutex(true,"Local\\TrayNest10",out first)){
            if(!first)return;
            Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
            try{using(var box=new Box()){box.FormClosed+=(s,e)=>Application.ExitThread();Application.Run();}}
            catch(Exception e){MessageBox.Show(e.Message,"DragonNest");}
        }
    }
}
