@echo off
setlocal
cd /d "%~dp0"
if not exist "build\app\" mkdir "build\app"
"%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /nologo /reference:System.Web.Extensions.dll /target:winexe /platform:x64 /win32manifest:src\app.manifest /win32icon:src\TrayNest10.ico /resource:src\TrayNest10.ico,TrayNest10.ico /out:build\app\TrayNest10.exe src\Box.cs src\Tray.cs
exit /b %errorlevel%
