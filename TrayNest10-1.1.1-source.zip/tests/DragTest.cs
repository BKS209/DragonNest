using System;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Linq;
using System.IO;
internal class DragTest {
    [DllImport("user32")] static extern IntPtr FindWindowEx(IntPtr h,IntPtr a,string c,string n);
    [DllImport("user32")] static extern IntPtr SendMessage(IntPtr h,int msg,IntPtr w,IntPtr l);
    [DllImport("user32")] static extern void mouse_event(uint flags,int x,int y,int data,UIntPtr extra);
    [DllImport("user32")] static extern IntPtr WindowFromPoint(Point p);
    static void Wait(int ms){var t=Stopwatch.StartNew();while(t.ElapsedMilliseconds<ms){Application.DoEvents();Thread.Sleep(10);}}
    static void Popup(){
        if(Tray.IsWindowVisible(Tray.OverflowWindow))return;
        ToggleOverflow();
        if(!Tray.IsWindowVisible(Tray.OverflowWindow))throw new Exception("隐藏区未打开");
    }
    static void ToggleOverflow(){
        var task=Tray.FindWindow("Shell_TrayWnd",null);
        var area=FindWindowEx(task,IntPtr.Zero,"TrayNotifyWnd",null);
        var button=FindWindowEx(area,IntPtr.Zero,"Button",null);
        if(button!=IntPtr.Zero)SendMessage(button,0xf5,IntPtr.Zero,IntPtr.Zero);
        Wait(800);
    }
    [DllImport("user32")] static extern void keybd_event(byte key,byte scan,uint flags,UIntPtr extra);
    static void MouseAt(Point point,uint button){
        var desktop=SystemInformation.VirtualScreen;
        mouse_event(0xc001|button,(point.X-desktop.Left)*65535/(desktop.Width-1),
            (point.Y-desktop.Top)*65535/(desktop.Height-1),0,UIntPtr.Zero);
    }
    static void Drag(Point from,Point to,bool cancel=false){
        Cursor.Position=from;Wait(100);MouseAt(from,2);
        try{Wait(80);for(int i=1;i<=8;i++){Cursor.Position=new Point(from.X+(to.X-from.X)*i/8,from.Y+(to.Y-from.Y)*i/8);Wait(45);}if(cancel){keybd_event(27,0,0,UIntPtr.Zero);Wait(160);keybd_event(27,0,2,UIntPtr.Zero);}}
        finally{MouseAt(to,4);}Wait(700);
    }
    static bool CheckOfflineLayout(string directory){
        var offlineFile=Path.Combine(directory,"offline.xml");
        var offline=new Layout();
        for(int i=0;i<5;i++)offline.Order.Add(@"C:\traynest-offline.exe|"+i);
        using(var output=File.Create(offlineFile))new System.Xml.Serialization.XmlSerializer(typeof(Layout)).Serialize(output,offline);
        try{
            using(var compact=new Box(offlineFile)){
                compact.OpenBox();Wait(300);
                var tiles=compact.Controls.OfType<FlowLayoutPanel>().Single();
                int dpi;
                using(var graphics=tiles.CreateGraphics())dpi=(int)Math.Round(graphics.DpiX);
                int cell=(40*dpi+48)/96;
                var minimum=new Size(cell+tiles.Padding.Horizontal,cell+tiles.Padding.Vertical);
                bool empty=tiles.Controls.Count==0&&compact.ClientSize==minimum;
                Console.WriteLine("offline-entries-collapsed="+empty+" size="+compact.ClientSize);
                var draw=typeof(Box).GetMethod("DrawItems",
                    System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic);
                var sample=Enumerable.Range(1,9).Select(id=>new Entry{
                    Key=Application.ExecutablePath+"|"+id,Path=Application.ExecutablePath,Id=id
                }).ToArray();
                bool layout=true;
                foreach(int count in new[]{1,2,4,5,9,2,0}){
                    draw.Invoke(compact,new object[]{sample.Take(count).ToArray()});
                    int columns=Math.Min(Math.Max(count,1),4);
                    int rows=Math.Max(1,(count+3)/4);
                    var expected=new Size(columns*cell+tiles.Padding.Horizontal,rows*cell+tiles.Padding.Vertical);
                    bool fits=compact.ClientSize==expected&&tiles.Controls.Count==count
                        &&tiles.Controls.Cast<Control>().Select((control,i)=>
                            control.Left==tiles.Padding.Left+i%4*cell&&control.Top==tiles.Padding.Top+i/4*cell
                            &&(string)control.Tag==sample[i].Key).All(ok=>ok);
                    Console.WriteLine("horizontal="+fits+" count="+count+" size="+compact.ClientSize);
                    layout&=fits;
                }
                compact.ExitBox();return empty&&layout;
            }
        }finally{File.Delete(offlineFile);}
    }
    [STAThread] static int Main(string[] args){
        Debug.Listeners.Add(new TextWriterTraceListener(Console.Out));Application.EnableVisualStyles();
        var pos=Cursor.Position;
        var directory=Path.Combine(Path.GetTempPath(),"TrayNest10-test-"+Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        if(args.Contains("--layout-only")){try{return CheckOfflineLayout(directory)?0:11;}finally{Directory.Delete(directory);}}
        using(var fixture=Process.Start(new ProcessStartInfo(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"TrayProbe.exe"),"--fixture"){CreateNoWindow=true,UseShellExecute=false})){
            try{Wait(1500);
                using(var box=new Box(Path.Combine(directory,"layout.xml"))){
                    if(Tray.IsWindowVisible(Tray.OverflowWindow))ToggleOverflow();
                    Popup();
                    Console.WriteLine("system-open-keeps-box-closed="+!box.Visible);
                    if(box.Visible)return 8;
                    box.OpenBox();
                    Console.WriteLine("acrylic="+typeof(Box).GetField("acrylic",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(box));
                    Cursor.Position=Screen.PrimaryScreen.WorkingArea.Location;
                    ToggleOverflow();
                    bool closedWithSystem=!box.Visible&&!Tray.IsWindowVisible(Tray.OverflowWindow);
                    Console.WriteLine("system-close-dismisses-box="+closedWithSystem);
                    if(!closedWithSystem)return 9;
                    Popup();
                    box.OpenBox();
                    var e=Tray.List().First(x=>x.Name=="TrayProbe"&&x.Overflow&&!x.Hidden);
                    var from=new Point(e.Rect.Left+e.Rect.Width/2,e.Rect.Top+e.Rect.Height/2);
                    var to=box.PointToScreen(new Point(33,34));
                    if(WindowFromPoint(from)!=e.Bar||box.GetChildAtPoint(box.PointToClient(to))==null)throw new Exception("测试入口受遮挡");
                    Drag(from,to);
                    bool hidden=Tray.List().Any(x=>x.Key==e.Key&&x.Hidden);Console.WriteLine("drag-in="+hidden);
                    if(!hidden){Console.WriteLine("after visible="+box.Visible+" actual="+Cursor.Position+" overflow="+Tray.IsWindowVisible(Tray.OverflowWindow));return 1;}
                    var grid=box.Controls.OfType<FlowLayoutPanel>().First();
                    var cell=grid.Controls.Cast<Control>().First(x=>Equals(x.Tag,e.Key));
                    var icon=(PictureBox)cell;
                    Console.WriteLine("tile="+cell.Size+" image="+icon.Image.Size);
                    int expectedIcon=cell.Width*16/40;
                    if(Math.Abs(icon.Image.Width-expectedIcon)>1||box.ClientSize.Width!=cell.Width+grid.Padding.Horizontal)return 10;
                    Popup();
                    var target=Tray.List().First(x=>x.Overflow&&!x.Hidden);
                    var destination=new Point(target.Rect.Left+target.Rect.Width/2,target.Rect.Top+target.Rect.Height/2);
                    Drag(cell.PointToScreen(new Point(cell.Width/2,cell.Height/2)),destination);
                    bool visible=Tray.List().Any(x=>x.Key==e.Key&&!x.Hidden);
                    Console.WriteLine("drag-out="+visible);if(!visible)return 2;
                    Popup();to=box.PointToScreen(new Point(33,34));e=Tray.List().First(x=>x.Key==e.Key);from=new Point(e.Rect.Left+e.Rect.Width/2,e.Rect.Top+e.Rect.Height/2);
                    Drag(from,to,true);bool cancelled=Tray.List().Any(x=>x.Key==e.Key&&!x.Hidden)&&grid.Controls.Count==0;
                    Console.WriteLine("escape="+cancelled);if(!cancelled)return 4;
                    Popup();Wait(500);Drag(from,to);if(!Tray.List().Any(x=>x.Key==e.Key&&x.Hidden))return 5;
                    box.ExitBox();bool restored=Tray.List().Any(x=>x.Key==e.Key&&!x.Hidden);
                    Console.WriteLine("exit-restored="+restored);if(!restored)return 6;
                    using(var reopened=new Box(Path.Combine(directory,"layout.xml"))){reopened.OpenBox();Wait(600);
                        bool remembered=Tray.List().Any(x=>x.Key==e.Key&&x.Hidden);
                        Console.WriteLine("layout-reapplied="+remembered);reopened.ExitBox();if(!remembered)return 7;}
                    return 0;
                }
            }catch(Exception ex){Console.WriteLine(ex.Message);return 3;}
            finally{Cursor.Position=pos;if(!fixture.HasExited)fixture.Kill();if(File.Exists(Path.Combine(directory,"layout.xml")))File.Delete(Path.Combine(directory,"layout.xml"));if(Directory.Exists(directory))Directory.Delete(directory);}
        }
    }
}
