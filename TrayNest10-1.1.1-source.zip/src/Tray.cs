using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

internal class Entry {
    public IntPtr Bar, Owner, IconHandle;
    public int Command, Index, Id, Callback, Version;
    public bool Hidden, Overflow;
    public string Key, Path, Name;
    public Rectangle Rect;
}

internal static class Tray {
    [DllImport("user32",CharSet=CharSet.Unicode)] internal static extern IntPtr FindWindow(string c,string n);
    [DllImport("user32",CharSet=CharSet.Unicode)] static extern IntPtr FindWindowEx(IntPtr p,IntPtr a,string c,string n);
    [DllImport("user32")] static extern uint GetWindowThreadProcessId(IntPtr h,out int p);
    [DllImport("user32")] static extern bool ClientToScreen(IntPtr h,ref Point p);
    [DllImport("user32")] internal static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32")] internal static extern short GetAsyncKeyState(int k);
    [DllImport("user32")] static extern IntPtr SendMessageTimeout(IntPtr h,uint m,IntPtr w,IntPtr l,uint flags,uint timeout,out IntPtr result);
    [DllImport("kernel32")] static extern IntPtr OpenProcess(int rights,bool inherit,int pid);
    [DllImport("kernel32")] static extern IntPtr VirtualAllocEx(IntPtr p,IntPtr addr,UIntPtr size,uint type,uint prot);
    [DllImport("kernel32")] static extern bool VirtualFreeEx(IntPtr p,IntPtr addr,UIntPtr size,uint type);
    [DllImport("kernel32")] static extern bool ReadProcessMemory(IntPtr p,IntPtr addr,byte[] data,IntPtr size,out IntPtr read);
    [DllImport("kernel32")] static extern bool CloseHandle(IntPtr h);
    [DllImport("kernel32",CharSet=CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr p,int flags,System.Text.StringBuilder s,ref int len);
    static long Message(IntPtr h,uint m,int w,IntPtr l) {
        IntPtr r;
        if(SendMessageTimeout(h,m,new IntPtr(w),l,2,250,out r)==IntPtr.Zero) throw new IOException("托盘没有响应");
        return r.ToInt64();
    }
    static byte[] Read(IntPtr p,IntPtr addr,int n) {
        byte[] b=new byte[n]; IntPtr count;
        return ReadProcessMemory(p,addr,b,new IntPtr(n),out count)&&count.ToInt64()==n?b:null;
    }
    static IntPtr Child(IntPtr p,string c) {return p==IntPtr.Zero?IntPtr.Zero:FindWindowEx(p,IntPtr.Zero,c,null);}
    internal static IntPtr OverflowWindow { get {return FindWindow("NotifyIconOverflowWindow",null);} }
    internal static List<Entry> List() {
        var all=new List<Entry>();
        var main=Child(Child(Child(FindWindow("Shell_TrayWnd",null),"TrayNotifyWnd"),"SysPager"),"ToolbarWindow32");
        Scan(main,false,all); Scan(Child(OverflowWindow,"ToolbarWindow32"),true,all);
        return all;
    }
    static void Scan(IntPtr bar,bool overflow,List<Entry> all) {
        if(bar==IntPtr.Zero)return;
        int pid; GetWindowThreadProcessId(bar,out pid);
        var p=OpenProcess(0x418,false,pid); if(p==IntPtr.Zero)return;
        var buf=VirtualAllocEx(p,IntPtr.Zero,(UIntPtr)64,0x3000,4);
        try {
            if(buf==IntPtr.Zero)return;
            long count=Message(bar,0x418,0,IntPtr.Zero);
            for(int i=0;i<count && i<1024;i++){
                if(Message(bar,0x417,i,buf)==0)continue;
                var b=Read(p,buf,32); if(b==null)continue;
                var d=Read(p,new IntPtr(BitConverter.ToInt64(b,16)),32); if(d==null)continue;
                var owner=new IntPtr(BitConverter.ToInt64(d,0)); int app;
                if(GetWindowThreadProcessId(owner,out app)==0)continue;
                var ph=OpenProcess(0x1000,false,app); if(ph==IntPtr.Zero)continue;
                var s=new System.Text.StringBuilder(2048);int len=s.Capacity;
                bool ok=QueryFullProcessImageName(ph,0,s,ref len);CloseHandle(ph);if(!ok)continue;
                int id=BitConverter.ToInt32(d,8);
                var e=new Entry {Bar=bar,Index=i,Owner=owner,Command=BitConverter.ToInt32(b,4),Id=id,IconHandle=new IntPtr(BitConverter.ToInt64(d,24)),Callback=BitConverter.ToInt32(d,12),Version=BitConverter.ToInt32(d,20),Hidden=(b[8]&8)!=0,Overflow=overflow,Path=s.ToString()};
                e.Key=e.Path.ToUpperInvariant()+"|"+id;e.Name=Path.GetFileNameWithoutExtension(e.Path);
                if(Message(bar,0x41d,i,buf)!=0){
                    var r=Read(p,buf,16);if(r!=null){
                        var pt=new Point(BitConverter.ToInt32(r,0),BitConverter.ToInt32(r,4));
                        int w=BitConverter.ToInt32(r,8)-pt.X,h=BitConverter.ToInt32(r,12)-pt.Y;
                        ClientToScreen(bar,ref pt);e.Rect=new Rectangle(pt,new Size(w,h));
                    }
                }
                all.Add(e);
            }
        } finally {if(buf!=IntPtr.Zero)VirtualFreeEx(p,buf,UIntPtr.Zero,0x8000);CloseHandle(p);}
    }
    [DllImport("user32")] static extern IntPtr CopyIcon(IntPtr icon);
    [DllImport("user32")] static extern bool DestroyIcon(IntPtr icon);
    [DllImport("user32",EntryPoint="GetClassLongPtrW")] static extern IntPtr GetClassLongPtr(IntPtr window,int index);
    internal static Bitmap ReadIcon(Entry entry,int size){
        var image=CopyIconImage(entry.IconHandle,size);
        if(image!=null)return image;

        image=ReadDragonGirlIcon(entry,size);
        if(image!=null)return image;

        // Query the owner only during a redraw. Window and class handles are borrowed.
        foreach(int kind in new[]{0,2,1}){
            IntPtr icon;
            if(SendMessageTimeout(entry.Owner,0x7f,new IntPtr(kind),IntPtr.Zero,2,35,out icon)==IntPtr.Zero)break;
            image=CopyIconImage(icon,size);
            if(image!=null)return image;
        }
        image=CopyIconImage(GetClassLongPtr(entry.Owner,-34),size)
            ??CopyIconImage(GetClassLongPtr(entry.Owner,-14),size);
        if(image!=null)return image;

        try{
            using(var icon=Icon.ExtractAssociatedIcon(entry.Path))
            using(var bitmap=icon==null?null:icon.ToBitmap())
                return bitmap==null?null:new Bitmap(bitmap,size,size);
        }catch(ArgumentException){return null;}
        catch(IOException){return null;}
        catch(UnauthorizedAccessException){return null;}
        catch(ExternalException){return null;}
    }
    static Bitmap ReadDragonGirlIcon(Entry entry,int size){
        if(!string.Equals(Path.GetFileName(entry.Path),"DragonGirl.exe",StringComparison.OrdinalIgnoreCase))return null;

        try{
            var plugin=Path.Combine(Path.GetDirectoryName(entry.Path),"resources","app","assets","characters");
            var profile=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"Codex DragonGirl");
            var settingsPath=Path.Combine(profile,"settings.json");
            string asset=Path.Combine(plugin,"codex-dragon-girl.png");
            if(File.Exists(settingsPath)){
                var settings=new System.Web.Script.Serialization.JavaScriptSerializer()
                    .Deserialize<Dictionary<string,object>>(File.ReadAllText(settingsPath));
                object value;
                var custom=settings!=null&&settings.TryGetValue("characterAsset",out value)?value as string:null;
                if(!string.IsNullOrWhiteSpace(custom)){
                    if(custom=="."||custom==".."||Path.GetFileName(custom)!=custom||custom.IndexOfAny(Path.GetInvalidFileNameChars())>=0)return null;
                    asset=Path.Combine(profile,"assets",custom);
                }else if(settings!=null&&settings.TryGetValue("characterId",out value)&&string.Equals(value as string,"maro",StringComparison.Ordinal)){
                    asset=Path.Combine(plugin,"maro","idle.png");
                }
            }
            if(!File.Exists(asset))return null;
            using(var original=Image.FromFile(asset))
            using(var trayImage=new Bitmap(original,22,20)){
                int height=Math.Max(1,(size*20+11)/22);
                var image=new Bitmap(size,size);
                using(var graphics=Graphics.FromImage(image)){
                    graphics.InterpolationMode=System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    graphics.DrawImage(trayImage,new Rectangle(0,(size-height)/2,size,height));
                }
                return image;
            }
        }catch(ArgumentException){return null;}
        catch(InvalidOperationException){return null;}
        catch(IOException){return null;}
        catch(UnauthorizedAccessException){return null;}
        catch(ExternalException){return null;}
    }
    static Bitmap CopyIconImage(IntPtr borrowed,int size){
        if(borrowed==IntPtr.Zero)return null;
        var copy=CopyIcon(borrowed);
        if(copy==IntPtr.Zero)return null;
        try{
            using(var icon=Icon.FromHandle(copy))
            using(var bitmap=icon.ToBitmap())return new Bitmap(bitmap,size,size);
        }catch(ArgumentException){return null;}
        catch(ExternalException){return null;}
        finally{DestroyIcon(copy);}
    }
    [StructLayout(LayoutKind.Sequential)] struct NativeRect{public int Left,Top,Right,Bottom;}
    [DllImport("user32")] static extern bool GetWindowRect(IntPtr hwnd,out NativeRect rect);
    [DllImport("user32")] static extern bool SetWindowPos(IntPtr hwnd,IntPtr after,int x,int y,int width,int height,uint flags);
    internal static bool ArrangeFourInSquare(List<Entry> all){
        var icons=all.FindAll(e=>e.Overflow&&!e.Hidden);
        if(icons.Count!=4||icons.Exists(e=>e.Rect.Width<=0||e.Rect.Left!=icons[0].Rect.Left))return false;
        NativeRect taskbar;
        if(!GetWindowRect(FindWindow("Shell_TrayWnd",null),out taskbar)||taskbar.Right-taskbar.Left<=taskbar.Bottom-taskbar.Top)return false;
        var overflow=OverflowWindow;
        var bar=icons[0].Bar;
        NativeRect bounds;
        if(!IsWindowVisible(overflow)||!GetWindowRect(overflow,out bounds))return false;
        int pid;GetWindowThreadProcessId(bar,out pid);
        var process=OpenProcess(0x418,false,pid);
        if(process==IntPtr.Zero)return false;
        var buffer=VirtualAllocEx(process,IntPtr.Zero,(UIntPtr)16,0x3000,4);
        try{
            if(buffer==IntPtr.Zero)return false;
            Message(bar,0x427,2,buffer);
            int width=icons[0].Rect.Width*2,height=icons[0].Rect.Height*2;
            // RECT stores absolute right/bottom edges. Keep the edge nearest the taskbar fixed.
            int y=taskbar.Top<bounds.Top?bounds.Top:bounds.Bottom-height;
            bool parent=SetWindowPos(overflow,IntPtr.Zero,bounds.Right-width,y,width,height,0x14);
            bool child=SetWindowPos(bar,IntPtr.Zero,0,0,width,height,0x14);
            return parent&&child;
        }finally{
            if(buffer!=IntPtr.Zero)VirtualFreeEx(process,buffer,UIntPtr.Zero,0x8000);
            CloseHandle(process);
        }
    }
    [DllImport("user32")] static extern bool RedrawWindow(IntPtr hwnd,IntPtr rect,IntPtr region,uint flags);
    // Only the notification icon identity and hidden-state fields are needed.
    [StructLayout(LayoutKind.Explicit,Size=976)]
    struct NotifyIconData {
        [FieldOffset(0)] public uint Size;
        [FieldOffset(8)] public IntPtr Owner;
        [FieldOffset(16)] public int Id;
        [FieldOffset(20)] public uint Flags;
        [FieldOffset(296)] public uint State;
        [FieldOffset(300)] public uint StateMask;
    }
    [DllImport("shell32.dll",EntryPoint="Shell_NotifyIconW")]
    static extern bool ShellNotifyIcon(uint message,ref NotifyIconData icon);

    internal static bool Hide(Entry e,bool hide){
        var icon=new NotifyIconData{
            Size=(uint)Marshal.SizeOf(typeof(NotifyIconData)),Owner=e.Owner,Id=e.Id,
            Flags=8,State=hide?1u:0u,StateMask=1 // NIF_STATE, NIS_HIDDEN
        };
        // NIM_MODIFY lets Explorer recompute the overflow layout.
        if(ShellNotifyIcon(1,ref icon)&&(Message(e.Bar,0x40c,e.Command,IntPtr.Zero)!=0)==hide)return true;
        Message(e.Bar,0x404,e.Command,new IntPtr(hide?1:0));
        bool changed=(Message(e.Bar,0x40c,e.Command,IntPtr.Zero)!=0)==hide;
        if(changed)RedrawWindow(e.Bar,IntPtr.Zero,IntPtr.Zero,0x0001); // Invalidate this toolbar only.
        return changed;
    }
    [DllImport("user32")] static extern bool PostMessage(IntPtr window,int message,IntPtr w,IntPtr l);
    [DllImport("user32")] static extern bool AllowSetForegroundWindow(int pid);
    [StructLayout(LayoutKind.Sequential)]
    struct NotifyIconIdentifier {
        public int Size;
        public IntPtr Owner;
        public int Id;
        public Guid Guid;
    }
    [DllImport("shell32")] static extern int Shell_NotifyIconGetRect(ref NotifyIconIdentifier icon,out NativeRect rect);
    [DllImport("user32")] static extern bool ShowWindowAsync(IntPtr window,int command);

    // The tray-icon library checks Shell_NotifyIconGetRect before showing its menu.
    internal static bool MenuNeedsVisibleIcon(Entry entry){
        return entry.Hidden&&entry.Overflow&&entry.Version==0&&entry.Callback==6002;
    }
    internal static void OpenOverflow(){
        if(IsWindowVisible(OverflowWindow))return;
        var area=Child(FindWindow("Shell_TrayWnd",null),"TrayNotifyWnd");
        var button=Child(area,"Button");
        if(button!=IntPtr.Zero)Message(button,0xf5,0,IntPtr.Zero); // BM_CLICK
    }
    internal static void CloseOverflow(){
        var overflow=OverflowWindow;
        if(IsWindowVisible(overflow))ShowWindowAsync(overflow,0);
    }
    internal static bool CanLocateIcon(Entry entry){
        var id=new NotifyIconIdentifier{Size=Marshal.SizeOf(typeof(NotifyIconIdentifier)),Owner=entry.Owner,Id=entry.Id};
        NativeRect rect;
        return Shell_NotifyIconGetRect(ref id,out rect)==0;
    }
    internal static void Click(Entry e,MouseButtons button,bool twice){
        int pid;GetWindowThreadProcessId(e.Owner,out pid);AllowSetForegroundWindow(pid);
        bool modern=e.Version==4;
        Point pt=Cursor.Position;
        int w=modern?((pt.X&65535)|(pt.Y<<16)):e.Id;
        int[] events=button==MouseButtons.Right?(modern?new[]{0x204,0x205,0x7b}:new[]{0x204,0x205}):
            twice?new[]{0x201,0x202,0x203,0x202}:modern?new[]{0x201,0x202,0x400}:new[]{0x201,0x202};
        foreach(int msg in events){
            int l=modern?((e.Id<<16)|msg):msg;
            if(e.Callback==0||!PostMessage(e.Owner,e.Callback,new IntPtr(w),new IntPtr(l)))throw new IOException("此图标未接受点击，可移回系统托盘操作");
        }
    }
}
