@echo off
setlocal
cd /d "%~dp0"
if not exist "build\tests\" mkdir "build\tests"
set "compiler=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
"%compiler%" /nologo /reference:System.Web.Extensions.dll /platform:x64 /out:build\tests\TrayProbe.exe src\Tray.cs tests\Probe.cs
if errorlevel 1 exit /b 1
"%compiler%" /nologo /reference:System.Web.Extensions.dll /platform:x64 /win32manifest:src\app.manifest /resource:src\TrayNest10.ico,TrayNest10.ico /main:DragTest /out:build\tests\DragTest.exe src\Tray.cs src\Box.cs tests\DragTest.cs
exit /b %errorlevel%
